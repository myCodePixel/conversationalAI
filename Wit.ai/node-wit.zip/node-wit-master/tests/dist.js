'use strict';

describe('dist', () => {
  require('./shared').runTests(require('../dist/index'));
});
