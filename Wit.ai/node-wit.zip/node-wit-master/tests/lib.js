'use strict';

describe('lib', () => {
  require('./shared').runTests(require('../index'));
});
