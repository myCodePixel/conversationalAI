# Changelog

[PyPI History][1]

[1]: https://pypi.org/project/DISTRIBUTION NAME/#history

## 0.2.0

### New Features
- Add v2 Endpoint (#38)

### Documentation
- Add sample readme, and sample agent (#15)

### Internal / Testing Changes
- Fix typo (#16)

