Client for Dialogflow API
=========================

.. automodule:: dialogflow_v2beta1
    :members:
    :inherited-members:
