Types for Dialogflow API Client
===============================

.. automodule:: dialogflow_v2beta1.types
    :members:
