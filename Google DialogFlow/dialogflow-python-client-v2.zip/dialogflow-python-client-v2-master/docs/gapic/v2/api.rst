Client for Dialogflow API
=========================

.. automodule:: dialogflow_v2
    :members:
    :inherited-members:
