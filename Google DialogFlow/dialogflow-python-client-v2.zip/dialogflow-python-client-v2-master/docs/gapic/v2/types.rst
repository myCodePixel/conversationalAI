Types for Dialogflow API Client
===============================

.. automodule:: dialogflow_v2.types
    :members:
